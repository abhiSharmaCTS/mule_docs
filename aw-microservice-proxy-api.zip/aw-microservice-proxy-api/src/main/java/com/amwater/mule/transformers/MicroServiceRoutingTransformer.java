package com.amwater.mule.transformers;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

public class MicroServiceRoutingTransformer extends AbstractMessageTransformer {

	private final String muleEvn = StringUtils.defaultString(System.getProperty("mule.env"));
	private final String propertyFileName = "aw-microservice-proxy-api-" +muleEvn+ ".properties";
	private Properties properties;

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {

		try {
			loadPropertiesFromFile();
		} catch (Exception e) {
			logger.error("Error in loading properties file ", e);
		}

		String requestPath = message.getInboundProperty("http.request.path");
		String listenerPath = message.getInboundProperty("http.listener.path");
		String forwardPath = requestPath.substring(listenerPath.length() - 2);

		logger.debug("requestPath = " + requestPath);
		logger.debug("listenerPath = " + listenerPath);
		logger.debug("forwardPath = " + forwardPath);

		if (StringUtils.isNotEmpty(forwardPath) && properties != null) {
			int endIndex = forwardPath.indexOf("/", 1);

			String forwardPathContext = "";
			if (endIndex > 1) {
				forwardPathContext = forwardPath.substring(1, endIndex);
			} else {
				forwardPathContext = forwardPath.substring(1);
			}

			String forwardHost = properties.getProperty("ms.host." + forwardPathContext);
			String forwardPort = properties.getProperty("ms.port." + forwardPathContext);

			message.setInvocationProperty("implementationHost", forwardHost);
			message.setInvocationProperty("implementationPort", forwardPort);

			logger.info("requestPath = " + requestPath + ", forwardPath = " + forwardPath + ", forwardPathContext = " + forwardPathContext + ", URL = " + forwardHost + ":" + forwardPort);

		}

		return message.getPayload();
	}

	public void loadPropertiesFromFile() throws FileNotFoundException, IOException, Exception {

		if (this.properties == null) {
			ClassLoader classLoader = getClass().getClassLoader();
			File file = new File(classLoader.getResource(propertyFileName).getFile());

			FileReader fileReader = new FileReader(file);
			BufferedReader bufferReader = null;
			try {
				bufferReader = new BufferedReader(fileReader);
				this.properties = new Properties();
				properties.load(bufferReader);

				logger.info("Loaded properties for microservices = " + properties);

			} catch (IOException e) {
				logger.error("Error in loading proeprties file. ", e);
				e.printStackTrace();
			} finally {
				if (bufferReader != null) {
					try {
						bufferReader.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				
				if(fileReader != null){
					try {
						fileReader.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}// End of loadPropertiesFromFile() Method

}
