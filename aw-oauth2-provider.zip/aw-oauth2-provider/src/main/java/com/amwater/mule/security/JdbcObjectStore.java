package com.amwater.mule.security;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.sql.SQLException;
import javax.inject.Inject;
import javax.sql.DataSource;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.ArrayHandler;
import org.mule.api.MuleContext;
import org.mule.api.context.MuleContextAware;
import org.mule.api.execution.ExecutionCallback;
import org.mule.api.transaction.TransactionConfig;
import org.mule.config.i18n.CoreMessages;
import org.mule.execution.TransactionalExecutionTemplate;
import org.mule.transaction.MuleTransactionConfig;
import org.mule.util.store.AbstractMonitoredObjectStore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.mule.api.store.ObjectStoreException;

/**
 * This class is a spring bean that represents the custom jdbc objectstore using
 * a database table and will be used to manage oauth tokens within for the
 * cluster environments to share tokens between nodes.
 */

public class JdbcObjectStore<T extends Serializable> extends AbstractMonitoredObjectStore<T>
		implements MuleContextAware {

	private DataSource dataSource;
	private TransactionConfig transactionConfig;
	QueryRunner queryRunner;
	private String insertQueryKey;
	private String selectQueryKey;
	private String deleteQueryKey;
	private String clearQueryKey;

	private static final Logger LOGGER = LoggerFactory.getLogger(JdbcObjectStore.class);

	@Inject
	MuleContext muleContext;

	public void init() {
		LOGGER.info("Initialized JdbcObjectStore.");
		transactionConfig = new MuleTransactionConfig();
		queryRunner = new QueryRunner(dataSource);
	}

	public DataSource getDataSource() {
		return dataSource;
	}

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public String getInsertQueryKey() {
		return insertQueryKey;
	}

	public String getSelectQueryKey() {
		return selectQueryKey;
	}

	public String getDeleteQueryKey() {
		return deleteQueryKey;
	}

	public String getClearQueryKey() {
		return clearQueryKey;
	}

	public void setInsertQueryKey(String insertQueryKey) {
		this.insertQueryKey = insertQueryKey;
	}

	public void setSelectQueryKey(String selectQueryKey) {
		this.selectQueryKey = selectQueryKey;
	}

	public void setDeleteQueryKey(String deleteQueryKey) {
		this.deleteQueryKey = deleteQueryKey;
	}

	public void setClearQueryKey(String clearQueryKey) {
		this.clearQueryKey = clearQueryKey;
	}

	@Override
	public boolean contains(Serializable key) throws ObjectStoreException {
		if (key == null) {
			throw new ObjectStoreException(CoreMessages.objectIsNull("id"));
		}
		Serializable value = retrieve(key);
		return value != null;
	}

	@Override
	public void store(Serializable key, Serializable value) throws ObjectStoreException {
		Object[] arguments = new Object[2];
		arguments[0] = key;
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ObjectOutputStream oos;
		try {
			oos = new ObjectOutputStream(baos);
			oos.writeObject(value);
		} catch (IOException e) {
			throw new ObjectStoreException(e);
		}
		arguments[1] = baos.toByteArray();
		LOGGER.info("Storing oauth token with key=" + key);
		update(insertQueryKey, arguments);
	}

	@Override
	public boolean isPersistent() {
		return false;
	}

	@Override
	public void clear() throws ObjectStoreException {
		update(clearQueryKey, new Object[0]);
	}

	private Object query(final String sql, final ResultSetHandler handler, final Object... arguments)
			throws ObjectStoreException {
		try {
			ExecutionCallback<Object> e = new ExecutionCallback<Object>() {
				public Object process() throws Exception {
					return JdbcObjectStore.this.queryRunner.query(sql, handler, arguments);
				}
			};
			return executeInTransactionTemplate(e);
		} catch (SQLException e) {
			throw new ObjectStoreException(e);
		} catch (Exception e) {
			throw new ObjectStoreException(e);
		}
	}

	private Object update(final String sql, final Object... arguments) throws ObjectStoreException {
		try {
			ExecutionCallback<Object> e = new ExecutionCallback<Object>() {
				public Object process() throws Exception {
					return Integer.valueOf(JdbcObjectStore.this.queryRunner.update(sql, arguments));
				}
			};
			return this.executeInTransactionTemplate(e);
		} catch (SQLException e) {
			throw new ObjectStoreException(e);
		} catch (Exception e) {
			throw new ObjectStoreException(e);
		}
	}

	private Object executeInTransactionTemplate(ExecutionCallback<Object> processingCallback) throws Exception {
		TransactionalExecutionTemplate<Object> executionTemplate = TransactionalExecutionTemplate
				.createTransactionalExecutionTemplate(muleContext, this.transactionConfig);
		return executionTemplate.execute(processingCallback);
	}

	@Override
	protected void expire() {
		// Do nothing
	}

	@SuppressWarnings("unchecked")
	@Override
	public T retrieve(Serializable key) throws ObjectStoreException {
		LOGGER.info("Retrierving token with key = " + key);
		Object[] row = (Object[]) this.query(selectQueryKey, new ArrayHandler(), key);
		T t = null;
		if (row == null) {
			LOGGER.info("Retrieved token with key = " + key
					+ " is null, probably was expired or does not exist yet if initial call");
			return null;
		} else {
			LOGGER.info("Retrierved token object = " + row[1]);
			ByteArrayInputStream baip = new ByteArrayInputStream((byte[]) row[1]);
			ObjectInputStream ois;
			try {
				ois = new ObjectInputStream(baip);
				t = (T) ois.readObject();
			} catch (IOException e) {
				e.printStackTrace();
				throw new ObjectStoreException(e);
			} catch (ClassNotFoundException e) {
				throw new ObjectStoreException(e);
			}
		}
		return t;
	}

	@Override
	public T remove(Serializable key) throws ObjectStoreException {
		LOGGER.info("Token with key=" + key + " will be removed ...");
		if (key == null) {
			throw new ObjectStoreException(CoreMessages.objectIsNull("id"));
		}
		T value = retrieve(key);
		this.update(deleteQueryKey, new Object[] { key });
		LOGGER.info("Token with key=" + key + " was removed because of expiration!");
		return value;
	}

}
